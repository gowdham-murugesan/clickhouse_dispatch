#include "TargetSpecific.h"
#include <iostream>

#if USE_MULTITARGET_CODE
#include <immintrin.h>
#endif

DECLARE_DEFAULT_CODE(
    int funcImpl() {
        std::cout << toString(BuildArch) << std::endl;
        return 1;
    }) // DECLARE_DEFAULT_CODE

DECLARE_SSE42_SPECIFIC_CODE(
    int funcImpl() {
        std::cout << toString(BuildArch) << std::endl;
        return 2;
    }) // DECLARE_SSE42_SPECIFIC_CODE

DECLARE_AVX2_SPECIFIC_CODE(
    int funcImpl() {
        std::cout << toString(BuildArch) << std::endl;
        return 3;
    }) // DECLARE_AVX2_SPECIFIC_CODE

int main()
{
#if USE_MULTITARGET_CODE
    if (isArchSupported(DB::TargetArch::SSE42))
    {
        std::cout << TargetSpecific::SSE42::funcImpl() << std::endl;
        return 0;
    }
    if (isArchSupported(DB::TargetArch::AVX2))
    {
        std::cout << TargetSpecific::AVX2::funcImpl() << std::endl;
        return 0;
    }
#endif
    std::cout << TargetSpecific::Default::funcImpl() << std::endl;
    return 0;
}