#include "TargetSpecific.h"
#include <iostream>

#if USE_MULTITARGET_CODE
#include <immintrin.h>
#endif

class TestClass
{
public:
    MULTITARGET_FUNCTION_AVX512BW_AVX512F_AVX2_SSE42(
        MULTITARGET_FUNCTION_HEADER(int), testFunctionImpl, MULTITARGET_FUNCTION_BODY((int value) {
            std::cout << value << std::endl;
            return value;
        }))

    void testFunction(int value)
    {
        if (isArchSupported(DB::TargetArch::AVX512BW))
        {
            std::cout << DB::toString(DB::TargetArch::AVX512BW) << std::endl;
            testFunctionImplAVX512BW(value);
        }
        else if (isArchSupported(DB::TargetArch::AVX512F))
        {
            std::cout << DB::toString(DB::TargetArch::AVX512F) << std::endl;
            testFunctionImplAVX512F(value);
        }
        else if (isArchSupported(DB::TargetArch::AVX2))
        {
            std::cout << DB::toString(DB::TargetArch::AVX2) << std::endl;
            testFunctionImplAVX2(value);
        }
        else if (isArchSupported(DB::TargetArch::SSE42))
        {
            std::cout << DB::toString(DB::TargetArch::SSE42) << std::endl;
            testFunctionImplSSE42(value);
        }
        else
        {
            std::cout << DB::toString(DB::TargetArch::Default) << std::endl;
            testFunctionImpl(value);
        }
    }
};

int main()
{
    TestClass test;
    test.testFunction(1);
}