#include "TargetSpecific.h"
#include <iostream>

#if USE_MULTITARGET_CODE
#include <immintrin.h>
#endif

DECLARE_MULTITARGET_CODE(
    int funcImpl() {
        std::cout << toString(BuildArch) << std::endl;
        return 1;
    }) // DECLARE_MULTITARGET_CODE

int main()
{
#if USE_MULTITARGET_CODE
if (isArchSupported(DB::TargetArch::AMXBF16))
    {
        std::cout << TargetSpecific::SSE42::funcImpl() << std::endl;
        return 0;
    }
    if (isArchSupported(DB::TargetArch::SSE42))
    {
        std::cout << TargetSpecific::SSE42::funcImpl() << std::endl;
        return 0;
    }
    if (isArchSupported(DB::TargetArch::AVX2))
    {
        std::cout << TargetSpecific::AVX2::funcImpl() << std::endl;
        return 0;
    }
#endif
    std::cout << TargetSpecific::Default::funcImpl() << std::endl;
    return 0;
}